//
//  CZEmoticonAttachment.swift
//  007-表情键盘
//
//  Created by apple on 16/7/11.
//  Copyright © 2016年 itcast. All rights reserved.
//

import UIKit

/// 表情附件
class CZEmoticonAttachment: NSTextAttachment {

    /// 表情纯文本，用于发送给服务器
    var chs: String?
}
